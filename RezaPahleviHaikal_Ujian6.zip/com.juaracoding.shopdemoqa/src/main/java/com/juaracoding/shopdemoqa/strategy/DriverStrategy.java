package com.juaracoding.shopdemoqa.strategy;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {
	WebDriver setStrategy();
}

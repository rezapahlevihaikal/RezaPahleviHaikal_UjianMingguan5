package com.juaracoding.shopdemoqa.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.juaracoding.shopdemoqa")
public class AutomationFrameworkConfig {
	public AutomationFrameworkConfig() {
		
	}
}
